# DOLLY

Documents, cloned on-chain. Forever.

DOLLY anchors document uploads (PDF, DOCX, MP3, etc.) on [Shelby Protocol](https://shelby.xyz)'s
decentralized hot storage, and treats every revision as a linked clone on
Aptos L1 — so a file's full version history is provable on-chain, not just
its current state.

## Structure

- `index.html` — the front end. Single static file, no build step. Open it
  directly in a browser, or deploy to Vercel/Netlify by dragging it in.
- `contract/` — the Move smart contract (`dolly::vault`) that stores each
  wallet's clone lineage on Aptos. See `contract/README.md` for deploy steps.

## Status

Front end is a working demo (simulated Shelby SDK calls + simulated
on-chain commits). Contract is written but not yet deployed. Next step is
wiring the two together: replace the simulated calls in `index.html` with
real `@shelby-protocol/sdk` uploads and `dolly::vault::anchor_clone`
transactions signed via Petra.

## Stack

- Aptos L1 (contract, wallet auth)
- Shelby Protocol (decentralized file storage)
- Move (smart contract)
- Vanilla HTML/CSS/JS (front end — no framework)
